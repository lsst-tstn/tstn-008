-- MySQL dump 10.14  Distrib 5.5.56-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: lsst_events
-- ------------------------------------------------------
-- Server version	5.5.56-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `BOOLEAN_EVENT`
--

DROP TABLE IF EXISTS `BOOLEAN_EVENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BOOLEAN_EVENT` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `EVENT_TYPE_ID` int(11) NOT NULL,
  `REF_VALUE` tinyint(1) NOT NULL DEFAULT '0',
  `EVENT_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_BOOLEAN_EVENT_BOOLEAN_TYPE_ID` (`EVENT_TYPE_ID`),
  KEY `FK_BOOLEAN_EVENT_EVENT_ID` (`EVENT_ID`),
  CONSTRAINT `FK_BOOLEAN_EVENT_BOOLEAN_TYPE_ID` FOREIGN KEY (`EVENT_TYPE_ID`) REFERENCES `BOOLEAN_TYPE` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=161 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BOOLEAN_EVENT`
--

LOCK TABLES `BOOLEAN_EVENT` WRITE;
/*!40000 ALTER TABLE `BOOLEAN_EVENT` DISABLE KEYS */;
INSERT INTO `BOOLEAN_EVENT` VALUES (1,1,1,1),(2,1,1,3),(3,1,1,4),(4,1,1,5),(6,1,1,7),(7,1,1,8),(8,1,1,9),(9,1,0,10),(10,1,0,11),(11,1,1,12),(13,1,1,6),(15,1,1,18),(16,1,1,19),(17,1,1,20),(18,1,1,21),(19,1,1,22),(20,1,1,23),(21,1,1,24),(22,1,1,25),(23,1,1,26),(24,1,1,27),(25,1,1,28),(26,1,1,29),(27,1,1,30),(28,1,1,31),(29,1,1,32),(30,1,1,33),(31,1,1,34),(34,1,1,37),(35,1,1,35),(36,1,1,36),(37,1,1,38),(38,1,1,39),(39,1,1,40),(40,1,1,41),(41,1,1,42),(42,1,1,43),(43,1,1,44),(44,1,1,45),(45,1,1,46),(46,1,1,47),(47,1,1,48),(48,1,1,49),(49,1,1,50),(50,1,1,50),(51,1,1,51),(52,1,1,52),(53,1,1,53),(54,1,1,17),(55,1,1,64),(56,1,1,65),(57,1,1,66),(58,1,1,67),(59,1,1,68),(60,1,1,69),(61,1,1,70),(62,1,1,71),(63,1,1,72),(64,1,1,73),(65,1,1,74),(66,1,1,75),(67,1,1,76),(68,1,1,77),(69,1,1,78),(70,1,1,79),(71,1,1,80),(72,1,1,81),(73,1,1,82),(74,1,1,83),(75,1,1,84),(76,1,1,85),(77,1,1,86),(78,1,1,87),(79,1,1,88),(80,1,1,89),(81,1,1,90),(82,1,1,91),(83,1,1,92),(84,1,1,93),(85,1,1,94),(86,1,1,95),(87,1,1,96),(88,1,1,97),(89,1,1,98),(90,1,1,99),(91,1,1,100),(92,1,1,101),(93,1,1,102),(94,1,1,103),(95,1,1,104),(96,1,1,105),(97,1,1,106),(98,1,1,107),(99,1,1,108),(100,1,1,109),(101,1,1,110),(102,1,1,111),(103,1,1,112),(104,1,1,113),(105,1,1,114),(106,1,1,115),(107,1,1,116),(108,1,1,117),(109,1,1,118),(110,1,1,119),(111,1,1,120),(112,1,0,121),(113,1,0,122),(114,1,1,123),(115,1,1,124),(116,1,1,125),(117,1,1,126),(118,1,1,127),(119,1,1,128),(120,1,1,129),(121,1,1,130),(122,1,1,131),(123,1,1,132),(124,1,1,140),(125,1,1,141),(126,1,1,142),(127,1,1,143),(128,1,1,144),(129,1,1,145),(130,1,1,146),(131,1,1,147),(132,1,0,148),(133,1,0,149),(134,1,1,150),(135,1,1,151),(136,1,1,152),(137,1,1,153),(138,1,1,154),(139,1,1,155),(140,1,1,156),(141,1,1,157),(142,1,1,158),(143,1,1,159),(144,1,1,160),(145,1,1,161),(146,1,1,162),(147,1,1,163),(148,1,1,164),(149,1,1,165),(150,1,1,166),(151,1,1,167),(152,1,1,168),(153,1,1,169),(154,1,1,170),(155,1,1,171),(156,1,1,172),(157,1,1,173),(158,1,1,174),(159,1,1,175),(160,1,1,176);
/*!40000 ALTER TABLE `BOOLEAN_EVENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `BOOLEAN_EVENTS`
--

DROP TABLE IF EXISTS `BOOLEAN_EVENTS`;
/*!50001 DROP VIEW IF EXISTS `BOOLEAN_EVENTS`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `BOOLEAN_EVENTS` (
  `NAME` tinyint NOT NULL,
  `DESCRIPTION` tinyint NOT NULL,
  `AREA` tinyint NOT NULL,
  `NUMBER` tinyint NOT NULL,
  `TYPE_ID` tinyint NOT NULL,
  `EVENTSYSTEM_ID` tinyint NOT NULL,
  `EVENTSYSTEM` tinyint NOT NULL,
  `TYPE` tinyint NOT NULL,
  `EVENT_TYPE` tinyint NOT NULL,
  `REF_VALUE` tinyint NOT NULL,
  `EVALUATION_STRING` tinyint NOT NULL,
  `ENABLED` tinyint NOT NULL,
  `TIME_TO_TRIGGER` tinyint NOT NULL,
  `ID` tinyint NOT NULL,
  `EVENT_TYPE_ID` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `BOOLEAN_TYPE`
--

DROP TABLE IF EXISTS `BOOLEAN_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BOOLEAN_TYPE` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(100) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BOOLEAN_TYPE`
--

LOCK TABLES `BOOLEAN_TYPE` WRITE;
/*!40000 ALTER TABLE `BOOLEAN_TYPE` DISABLE KEYS */;
INSERT INTO `BOOLEAN_TYPE` VALUES (1,'EQUAL'),(2,'CROSSING FROM'),(3,'CROSSING TO');
/*!40000 ALTER TABLE `BOOLEAN_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DOUBLE_EVENT`
--

DROP TABLE IF EXISTS `DOUBLE_EVENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DOUBLE_EVENT` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `EVENT_TYPE_ID` int(11) NOT NULL,
  `REF_VALUE` double NOT NULL DEFAULT '0',
  `DEADBAND` double DEFAULT '0',
  `HYSTERESIS` double DEFAULT '0',
  `EVENT_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_DOUBLE_EVENT_DOUBLE_TYPE_ID` (`EVENT_TYPE_ID`),
  KEY `FK_DOUBLE_EVENT_EVENT_ID` (`EVENT_ID`),
  CONSTRAINT `FK_DOUBLE_EVENT_DOUBLE_TYPE_ID` FOREIGN KEY (`EVENT_TYPE_ID`) REFERENCES `DOUBLE_TYPE` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DOUBLE_EVENT`
--

LOCK TABLES `DOUBLE_EVENT` WRITE;
/*!40000 ALTER TABLE `DOUBLE_EVENT` DISABLE KEYS */;
INSERT INTO `DOUBLE_EVENT` VALUES (1,3,30,0.1,0,2),(5,4,56,3,5,16),(7,2,4,0,0,54),(8,2,2,0,0,55),(9,2,4,0,0,56),(10,2,2,0,0,57),(11,1,1,0,0,58),(12,1,50000000000,0,0,59),(13,1,50000000,0,0,60),(14,1,1,0,0,61),(15,1,1,0,0,62),(16,1,50000000,0,0,63),(17,1,1,0,0,133),(18,1,1002,0,0,134),(19,1,1002,0,0,135),(20,1,1,0,0,136),(21,1,1,0,0,137),(22,1,2002,0,0,138),(23,1,999,0,0,139);
/*!40000 ALTER TABLE `DOUBLE_EVENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `DOUBLE_EVENTS`
--

DROP TABLE IF EXISTS `DOUBLE_EVENTS`;
/*!50001 DROP VIEW IF EXISTS `DOUBLE_EVENTS`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `DOUBLE_EVENTS` (
  `NAME` tinyint NOT NULL,
  `DESCRIPTION` tinyint NOT NULL,
  `AREA` tinyint NOT NULL,
  `NUMBER` tinyint NOT NULL,
  `TYPE_ID` tinyint NOT NULL,
  `EVENTSYSTEM_ID` tinyint NOT NULL,
  `EVENTSYSTEM` tinyint NOT NULL,
  `TYPE` tinyint NOT NULL,
  `EVENT_TYPE` tinyint NOT NULL,
  `REF_VALUE` tinyint NOT NULL,
  `EVALUATION_STRING` tinyint NOT NULL,
  `ENABLED` tinyint NOT NULL,
  `DEADBAND` tinyint NOT NULL,
  `HYSTERESIS` tinyint NOT NULL,
  `TIME_TO_TRIGGER` tinyint NOT NULL,
  `ID` tinyint NOT NULL,
  `EVENT_TYPE_ID` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `DOUBLE_TYPE`
--

DROP TABLE IF EXISTS `DOUBLE_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DOUBLE_TYPE` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(100) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DOUBLE_TYPE`
--

LOCK TABLES `DOUBLE_TYPE` WRITE;
/*!40000 ALTER TABLE `DOUBLE_TYPE` DISABLE KEYS */;
INSERT INTO `DOUBLE_TYPE` VALUES (1,'HIGHER'),(2,'LOWER'),(3,'EQUAL'),(4,'NOT EQUAL');
/*!40000 ALTER TABLE `DOUBLE_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EVENT`
--

DROP TABLE IF EXISTS `EVENT`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EVENT` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `EVENTSYSTEM_ID` int(11) NOT NULL,
  `NAME` varchar(155) NOT NULL,
  `DESCRIPTION` varchar(255) DEFAULT NULL,
  `AREA` varchar(50) DEFAULT NULL,
  `NUMBER` int(11) DEFAULT NULL,
  `EVALUATION_STRING` varchar(455) NOT NULL,
  `ENABLED` tinyint(1) DEFAULT '1',
  `TIME_TO_TRIGGER` varchar(10) DEFAULT '0',
  `TYPE_ID` int(11) NOT NULL,
  `EVENT_TYPE_ID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `FK_EVENT_TYPE_ID` (`TYPE_ID`),
  KEY `FK_EVENT_EVENT_TYPE_ID` (`EVENT_TYPE_ID`),
  KEY `FK_EVENT_EVENTSYSTEM_ID` (`EVENTSYSTEM_ID`),
  CONSTRAINT `FK_EVENT_EVENTSYSTEM_ID` FOREIGN KEY (`EVENTSYSTEM_ID`) REFERENCES `EVENTSYSTEM` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_EVENT_EVENT_TYPE_ID` FOREIGN KEY (`EVENT_TYPE_ID`) REFERENCES `EVENT_TYPE` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_EVENT_TYPE_ID` FOREIGN KEY (`TYPE_ID`) REFERENCES `TYPE` (`ID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=177 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EVENT`
--

LOCK TABLES `EVENT` WRITE;
/*!40000 ALTER TABLE `EVENT` DISABLE KEYS */;
INSERT INTO `EVENT` VALUES (3,2,'Temperature Increase','Cabinet Temperature increased above limit.','1300.CabTemp',1309,'~Door&&(((Cabinet Temperature 1+Cabinet Temperature 2)/2)>=High Cabinet Temperature)',1,'0',1,1),(4,2,'Temperature Drop','Cabinet Temperature decreased below limit.','1300.CabTemp',1308,'~Door&&(((Cabinet Temperature 1+Cabinet Temperature 2)/2)<=Low Cabinet Temperature)',1,'0',1,1),(5,2,'Critical Temperature Increase ','Cabinet Temperature increased above critical limit.','1300.CabTemp',1351,'~Door&&(((Cabinet Temperature 1+Cabinet Temperature 2)/2)>=Critical High Cabinet Temperature)',1,'0',2,1),(6,2,'Critical Temperature Drop','Cabinet Temperature decreased below critical limit.','1300.CabTemp',1350,'~Door&&(((Cabinet Temperature 1+Cabinet Temperature 2)/2)<=Critical Low Cabinet Temperature)',1,'0',2,1),(7,2,'Surface Temperature Increase','Surface temperature increased beyond limit.','1300.CabTemp',1311,'~Door&&((Surface Temperature-Ambient Temperature)>=High Surface Temperature)',1,'0',1,1),(8,2,'Surface Temperature Drop','Surface temperature decreased below limit.','1300.CabTemp',1310,'~Door&&((Surface Temperature-Ambient Temperature)<=Low Surface Temperature)',1,'0',1,1),(9,2,'Cabinet Below 3°C','Cabinet temperature dropped below 3°C. Shut down will initiate.','1300.CabTemp',1304,'(Cabinet Temperature 1<=3)||(Cabinet Temperature 2<=3)',1,'0',2,1),(10,2,'Cabinet Fan Faulty','The heat exchanger fan is faulty.','1300.CabTemp',1301,'Cabinet Fan Faulty',1,'0',2,1),(11,2,'Cabinet Heater Faulty','The cabinet heater is faulty.','1300.CabTemp',1302,'Cabinet Heater Faulty',1,'0',2,1),(12,2,'Cabinet Above 50°C','Cabinet temperature increased above 50°C. Shut down will initiate.','1300.CabTemp',1303,'(Cabinet Temperature 1>=50)||(Cabinet Temperature 2>=50)',1,'0',2,1),(17,12,'Speed Limit','The speed limit is being violated.','1000.CCW',1001,'Motor Speed_0>Motor Speed Limit||Motor Speed_1>Motor Speed Limit',1,'0',1,1),(18,12,'Positive Limit Switch Pressed','The positive limit switch is pressed.','1000.CCW',1002,'Limit Switch Positive&&~Limit Switch Override',1,'0',2,1),(19,12,'Negative Limit Switch Pressed','The negative limit switch was pressed.','1000.CCW',1003,'Limit Switch Negative&&~Limit Switch Override',1,'0',2,1),(20,12,'Driver 1 Fault','The driver of motor 1 is faulty.','1000.CCW',1004,'Fault Driver 1',1,'0',1,1),(21,12,'Driver 2 Fault','The driver of motor 2 is faulty.','1000.CCW',1005,'Fault Driver 2',1,'0',1,1),(22,12,'Lubrication Level 1 Low','The motor 1 lubrication level is low.','1000.CCW',1006,'Lubrication Level 1',1,'0',1,1),(23,12,'Lubrication Level 2 Low','The motor 2 lubrication level is low.','1000.CCW',1007,'Lubrication Level 2',1,'0',1,1),(24,12,'Driver Fault','Both motor drivers are faulty.','1000.CCW',1008,'Fault Driver 1&&Fault Driver 2',1,'0',2,1),(25,12,'Cricital Speed Limit','The critical speed limit was violated.','1000.CCW',1009,'Motor Speed_0>Critical Motor Speed Limit||Motor Speed_1>Critical Motor Speed Limit',1,'0',2,1),(26,12,'Positive Software Limit','The positive software limit was triggered.','1000.CCW',1010,'~Software Limit Switch Override&&((Motor Position_0>Positive Software Limit)||(Motor Position_1>Positive Software Limit))',1,'0',2,1),(27,12,'Negative Software Limit','The negative software limit was triggered.','1000.CCW',1011,'~Software Limit Switch Override&&((Motor Position_0<Negative Software Limit)||(Motor Position_1<Negative Software Limit))',1,'0',2,1),(28,12,'Camera Cable Wrap Safety','A safety issue has occurred in the camera cable wrap module.','1000.CCW',1012,'Safety Switch',1,'0',2,1),(29,14,'Mirror Cover Safety','A safety issue has occured in the mirror cover module.','900.MC',901,'Safety Switch',1,'0',2,1),(30,15,'Speed Limit','This event triggers if the parameter \"Motor Max Velocity\" is exceeded.','900.MC',904,'Velocity>Motor Max Velocity',1,'0',1,1),(31,16,'Speed Limit','This event triggers if the parameter \"Motor Max Velocity\" is exceeded.','900.MC',904,'Velocity>Motor Max Velocity',1,'0',1,1),(32,17,'Speed Limit','This event triggers if the parameter \"Motor Max Velocity\" is exceeded.','900.MC',904,'Velocity>Motor Max Velocity',1,'0',1,1),(33,18,'Speed Limit','This event triggers if the parameter \"Motor Max Velocity\" is exceeded.','900.MC',904,'Velocity>Motor Max Velocity',1,'0',1,1),(34,19,'Speed Limit','This event triggers if the parameter \"Motor Max Velocity\" is exceeded.','1500.MCL',1504,'Velocity>Motor Max Velocity',1,'0',1,1),(35,20,'Speed Limit','This event triggers if the parameter \"Motor Max Velocity\" is exceeded.','1500.MCL',1504,'Velocity>Motor Max Velocity',1,'0',1,1),(36,21,'Speed Limit','This event triggers if the parameter \"Motor Max Velocity\" is exceeded.','1500.MCL',1504,'Velocity>Motor Max Velocity',1,'0',1,1),(37,22,'Speed Limit','This event triggers if the parameter \"Motor Max Velocity\" is exceeded.','1500.MCL',1504,'Velocity>Motor Max Velocity',1,'0',1,1),(38,15,'Critical Speed Limit','This event triggers if the parameter \"Critical Max Motor Velocity\" is exceeded.','900.MC',903,'Velocity>Critical Max Motor Velocity',1,'0',2,1),(39,16,'Critical Speed Limit','This event triggers if the parameter \"Critical Max Motor Velocity\" is exceeded.','900.MC',903,'Velocity>Critical Max Motor Velocity',1,'0',2,1),(40,17,'Critical Speed Limit','This event triggers if the parameter \"Critical Max Motor Velocity\" is exceeded.','900.MC',903,'Velocity>Critical Max Motor Velocity',1,'0',2,1),(41,18,'Critical Speed Limit','This event triggers if the parameter \"Critical Max Motor Velocity\" is exceeded.','900.MC',903,'Velocity>Critical Max Motor Velocity',1,'0',2,1),(42,19,'Critical Speed Limit','This event triggers if the parameter \"Critical Max Motor Velocity\" is exceeded.','1500.MCL',1503,'Velocity>Critical Max Motor Velocity',1,'0',2,1),(43,20,'Critical Speed Limit','This event triggers if the parameter \"Critical Max Motor Velocity\" is exceeded.','1500.MCL',1503,'Velocity>Critical Max Motor Velocity',1,'0',2,1),(44,21,'Critical Speed Limit','This event triggers if the parameter \"Critical Max Motor Velocity\" is exceeded.','1500.MCL',1503,'Velocity>Critical Max Motor Velocity',1,'0',2,1),(45,22,'Critical Speed Limit','This event triggers if the parameter \"Critical Max Motor Velocity\" is exceeded.','1500.MCL',1503,'Velocity>Critical Max Motor Velocity',1,'0',2,1),(46,27,'Elevation Axis At Wrong Position','The Elevation Axis is out of the range defined for using the locking pins.','1400.LP',1401,'~(ElevationPosZeroMinus<ElevationPosition<ElevationPosZeroPlus)||~(ElevationPosNinetyMinus<ElevationPosition<ElevationPosNinetyPlus)',1,'0',2,1),(47,28,'Critical Speed Limit','The critical speed limit was violated.','1400.LP',1403,'Velocity>Max Critical Speed',1,'0',2,1),(49,29,'Critical Speed Limit','The critical speed limit was violated.','1400.LP',1404,'Velocity>Max Critical Speed',1,'0',2,1),(50,25,'Speed Limit','This event triggers if the parameter \"Platform Max Velocity\" is exceeded.','1200.DP',1201,'(Velocity1>Platform Max Velocity)||(Velocity2>Platform Max Velocity)',1,'0',1,1),(51,26,'Speed Limit','This event triggers if the parameter \"Platform Max Velocity\" is exceeded.','1200.DP',1202,'(Velocity1>Platform Max Velocity)||(Velocity2>Platform Max Velocity)',1,'0',1,1),(52,25,'Critical Speed Limit','This event triggers if the parameter \"Platform Max Critical Velocity\" is exceeded.','1200.DP',1203,'(Velocity1>Platform Max Critical Velocity)||(Velocity2>Platform Max Critical Velocity)',1,'0',2,1),(53,26,'Critical Speed Limit','This event triggers if the parameter \"Platform Max Critical Velocity\" is exceeded.','1200.DP',1204,'(Velocity1>Platform Max Critical Velocity)||(Velocity2>Platform Max Critical Velocity)',1,'0',2,1),(54,30,'Azimuth lost encoder heads','One or more encoder heads are lost, but the system can continue working','700.EIB',701,'Active Azimuth Heads',1,'0',1,2),(55,30,'Azimuth encoder heads bellow critical value','The available encoder heads do not allow to continue the operation','700.EIB',702,'Active Azimuth Heads',1,'0',2,2),(56,30,'Elevation lost encoder heads','One or more encoder heads are lost, but the system can continue working','700.EIB',703,'Active Elevation Heads',1,'0',1,2),(57,30,'Elevation encoder heads bellow critical value','The available encoder heads do not allow to continue the operation','700.EIB',704,'Active Elevation Heads',1,'0',2,2),(64,28,'Speed Limit','The speed limit was violated.','1400.LP',1405,'Velocity>Max Speed',1,'0',1,1),(65,29,'Speed Limit','The speed limit was violated.','1400.LP',1406,'Velocity>Max Speed',1,'0',1,1),(66,34,'Speed Limit','The speed limit was violated.','1100.BAL',1101,'Velocity>Max Speed',1,'0',1,1),(67,36,'Speed Limit','The speed limit was violated.','1100.BAL',1101,'Velocity>Max Speed',1,'0',1,1),(68,35,'Speed Limit','The speed limit was violated.','1100.BAL',1101,'Velocity>Max Speed',1,'0',1,1),(69,37,'Speed Limit','The speed limit was violated.','1100.BAL',1101,'Velocity>Max Speed',1,'0',1,1),(70,34,'Critical Speed Limit','The critical speed limit was violated.','1100.BAL',1101,'Velocity>Max Critical Speed',1,'0',2,1),(71,35,'Critical Speed Limit','The critical speed limit was violated.','1100.BAL',1101,'Velocity>Max Critical Speed',1,'0',2,1),(72,36,'Critical Speed Limit','The critical speed limit was violated.','1100.BAL',1101,'Velocity>Max Critical Speed',1,'0',2,1),(73,37,'Critical Speed Limit','The critical speed limit was violated.','1100.BAL',1101,'Velocity>Max Critical Speed',1,'0',2,1),(74,33,'Locking Pins in Invalid Positions','The locking pins are both in either the lock or test position.','1100.BAL',1109,'(~IsLock)||(~IsTest)',1,'0',1,1),(75,12,'Camera Deviation Limit','The camera deviation limit is being violated.','1000.CCW',1013,'(((Camera Position-Motor Position_0)>Maximum Camera Deviation)||(-(Camera Position-Motor Position_0)>Maximum Camera Deviation)||((Camera Position-Motor Position_1)>Maximum Camera Deviation)||(-(Camera Position-Motor Position_1)>Maximum Camera Deviation))&&~Tracking Camera Override',1,'0',1,1),(76,12,'Critical Camera Deviation Limit','The critical camera deviation limit is being violated.','1000.CCW',1014,'(((Camera Position-Motor Position_0)>Maximum Critical Camera Deviation)||(-(Camera Position-Motor Position_0)>Maximum Critical Camera Deviation)||((Camera Position-Motor Position_1)>Maximum Critical Camera Deviation)||(-(Camera Position-Motor Position_1)>Maximum Critical Camera Deviation))&&~Tracking Camera Override',1,'0',2,1),(77,32,'Locking Pins not Engaged','The locking pins are not in the test or lock position.','1200.DP',1206,'~(Lock Limit 1&&Lock Limit 2)',1,'0',2,1),(78,32,'Elevation Axis At Wrong Position','The Elevation Axis is out of the range defined for using the deployable platforms.','1200.DP',1205,'(ElevationPosition>Max Elevation Angle)||(ElevationPosition<Min Elevation Angle)',1,'0',2,1),(79,32,'Deployable Platform Safety','A safety issue has occurred in the deployable platform module.','1200.DP',1207,'Safety Switch',1,'0',2,1),(80,27,'Locking Pin Safety','A safety issue has occured in the locking pin module.','1400.LP',1407,'Safety Switch',1,'0',2,1),(81,33,'Balancing System Safety','A safety issue has occured in the balancing system module.','1100.BAL',1110,'Safety Switch',1,'0',2,1),(82,24,'Azimuth Cable Wrap Safety','A safety issue has occured in the azimuth cable wrap module.','300.ACW',312,'Safety Switch',1,'0',2,1),(83,24,'Cricital Speed Limit','The critical speed limit was violated.','300.ACW',309,'Motor Speed_0>Critical Motor Speed Limit||Motor Speed_1>Critical Motor Speed Limit',1,'0',2,1),(84,24,'Critical Azimuth Deviation Limit','The critical azimut deviation limit is being violated.','300.ACW',314,'(((Azimuth Position-Motor Position_0)>Maximum Critical Azimuth Deviation)||(-(Azimuth Position-Motor Position_0)>Maximum Critical Azimuth Deviation)||((Azimuth Position-Motor Positon_1)>Maximum Critical Azimuth Deviation)||(-(Azimuth Position-Motor Position_1)>Maximum Critical Azimuth Deviation)||(Azimuth LVDT>Maximum Critical Azimuth Deviation)||(-(Azimuth LVDT)>Maximum Critical Azimuth Deviation))&&Tracking Azimuth Override',1,'0',2,1),(87,24,'Driver Fault','Both motor drivers are faulty.','300.ACW',308,'Fault Driver 1&&Fault Driver 2',1,'0',2,1),(88,24,'Lubrication Level 1 Low','The motor 1 lubrication level is low.','300.ACW',306,'Lubrication Level 1',1,'0',1,1),(89,24,'Lubrication Level 2 Low','The motor 2 lubrication level is low.','300.CCW',307,'Lubrication Level 2',1,'0',1,1),(90,24,'Negative Limit Switch Pressed','The negative limit switch was pressed.','300.ACW',303,'Limit Switch Negative&&~Limit Switch Override',1,'0',2,1),(91,24,'Negative Software Limit','The negative software limit was triggered.','300.ACW',311,'~Software Limit Switch Override&&((Motor Position_0<Negative Software Limit)||(Motor Position_1<Negative Software Limit))',1,'0',2,1),(92,24,'Positive Limit Switch Pressed','The positive limit switch is pressed.','300.ACW',302,'Limit Switch Positive&&~Limit Switch Override',1,'0',2,1),(93,24,'Positive Software Limit','The positive software limit was triggered.','300.ACW',310,'~Software Limit Switch Override&&((Motor Position_0>Positive Software Limit)||(Motor Position_1>Positive Software Limit))',1,'0',2,1),(94,24,'Speed Limit','The speed limit is being violated.','300.ACW',301,'Motor Speed_0>Motor Speed Limit||Motor Speed_1>Motor Speed Limit',1,'0',1,1),(95,24,'Azimuth Deviation Limit','The azimuth deviation limit is being violated.','300.ACW',313,'(((Azimuth Position-Motor Position_0)>Maximum Azimuth Deviation)||(-(Azimuth Position-Motor Position_0)>Maximum Azimuth Deviation)||((Azimuth Position-Motor Position_1)>Maximum Azimuth Deviation)||(-(Azimuth Position-Motor Position_1)>Maximum Azimuth Deviation)||(Azimuth LVDT>Maximum Azimuth Deviation)||(-(Azimuth LVDT)>Maximum Azimuth Deviation))&&Tracking Azimuth Override',1,'0',1,1),(96,38,'ActionTimeout','Timeout when power on/off or change to remote/local mode','',0,'ActionTimeout',1,'0',2,1),(97,38,'CameraFansFailure','The fans of the camera section have a failure','',0,'CameraFansFailure',1,'0',2,1),(98,38,'M2FansFailure','The fans of the M2 section have a failure','',0,'M2FansFailure',1,'0',2,1),(99,38,'Heat Exchanger 1 Fan Failure','Failure in the fans of the heat exchanber 1','',0,'HeatExchangerFansFailure001',1,'0',2,1),(100,38,'Heat Exchanger 2 Fan Failure','Failure in the fans of the heat exchanber 2','',0,'HeatExchangerFansFailure002',1,'0',2,1),(101,38,'0201 3 Way valve Failure','Failure of the 0201 3 way valve','',0,'3wayValvesFailure0201',1,'0',2,1),(102,38,'0202 3 Way valve Failure','Failure of the 0202 3 way valve','',0,'3wayValvesFailure0202',1,'0',2,1),(103,38,'Electrical Cabinet 1 Control Failure','Failure of the temperature controller in electrical cabinet 1','',0,'ElectricalCabinetTempControlSystemFailure1',1,'0',2,1),(104,38,'Electrical Cabinet 2 Control Failure','Failure of the temperature controller in electrical cabinet 2','',0,'ElectricalCabinetTempControlSystemFailure2',1,'0',2,1),(105,38,'Electrical Cabinet 3 Control Failure','Failure of the temperature controller in electrical cabinet 3','',0,'ElectricalCabinetTempControlSystemFailure3',1,'0',2,1),(106,38,'Electrical Cabinet 4 Control Failure','Failure of the temperature controller in electrical cabinet 4','',0,'ElectricalCabinetTempControlSystemFailure4',1,'0',2,1),(107,38,'Temperature Alarm Cabinet 1','Alarm temperature for electrical cabinet 1','',0,'ElectricalCabinetTempAlarm1',1,'0',2,1),(108,38,'Temperature Alarm Cabinet 2','Alarm temperature for electrical cabinet 2','',0,'ElectricalCabinetTempAlarm2',1,'0',2,1),(109,38,'Temperature Alarm Cabinet 3','Alarm temperature for electrical cabinet 3','',0,'ElectricalCabinetTempAlarm3',1,'0',2,1),(110,38,'Temperature Alarm Cabinet 4','Alarm temperature for electrical cabinet 4','',0,'ElectricalCabinetTempAlarm4',1,'0',2,1),(111,38,'Temperature 0501','Temperature of the sensor 0501 out of range','',0,'Temp0501OutOfRange',1,'0',2,1),(112,38,'Temperature 0502','Temperature of the sensor 0502 out of range','',0,'Temp0502OutOfRange',1,'0',2,1),(113,38,'Temperature 0504','Temperature of the sensor 0504 out of range','',0,'Temp0504OutOfRange',1,'0',2,1),(114,38,'Temperature 0505','Temperature of the sensor 0505 out of range','',0,'Temp0505OutOfRange',1,'0',2,1),(115,38,'Temperature 0506','Temperature of the sensor 0506 out of range','',0,'Temp0506OutOfRange',1,'0',2,1),(116,38,'Temperature 0507','Temperature of the sensor 0507 out of range','',0,'Temp0507OutOfRange',1,'0',2,1),(117,38,'Humidity 0501','Humidity of the sensor 0501 out of range','',0,'Humidity0501OutOfRange',1,'0',2,1),(118,38,'Humidity 0502','Humidity of the sensor 0502 out of range','',0,'Humidity0502OutOfRange',1,'0',2,1),(119,38,'Humidity 0504','Humidity of the sensor 0504 out of range','',0,'Humidity0504OutOfRange',1,'0',2,1),(120,38,'Humidity 0505','Humidity of the sensor 0505 out of range','',0,'Humidity0505OutOfRange',1,'0',2,1),(121,38,'PLC Malfunction','The PLC for Top End chiller is working bad','',0,'PLCMalfunction',1,'0',2,1),(122,38,'Air Compressed Valve Failure','Failure of the compressed air valve','',0,'AirCompressedValveFailure',1,'0',2,1),(123,40,'Observation sequence alarm','The OSSs observation sequence returned an alarm','800.OSS',801,'Observation',1,'0',2,1),(124,40,'Cooling system alarm','The OSSs cooling system returned an alarm','800.OSS',802,'Cooling',1,'0',2,1),(125,40,'Main pump system alarm','The OSSs main pump  system returned an alarm','800.OSS',803,'Main Pump',1,'0',2,1),(126,40,'Circulation system alarm','The OSSs circulation system  returned an alarm','800.OSS',804,'Circulation',1,'0',2,1),(127,40,'Accumulator alarm','The OSSs accumulator returned an alarm','800.OSS',805,'Accumulator',1,'0',2,1),(128,40,'Connection lost with OSS','The maximum time without a OSS heartbeat has been exceeded','800.OSS',806,'Heartbeat>=Heartbeat Timeout',1,'0',2,1),(129,28,'Position Positive Limit','The maximum position was violated','1400.LP',1410,'Position>Max Position',1,'0',2,1),(130,29,'Position Positive Limit','The maximum position was violated','1400.LP',1410,'Position>Max Position',1,'0',2,1),(131,29,'Position Negative Limit','The Minimum position was violated','1400.LP',1411,'Position<Min Position',1,'0',2,1),(132,28,'Position Negative Limit','The Minimum position was violated','1400.LP',1411,'Position<Min Position',1,'0',2,1),(133,30,'Frames loss','UPD receiving data loop is loosing frames. The frames are not consecutive.','700.EIB',705,'Frame numbers OK counter',1,'0',1,2),(134,30,'Frames loss','UPD receiving data loop is loosing frames. The frames are not consecutive.','700.EIB',706,'Frame numbers OK counter',1,'0',2,2),(135,30,'Received Data not OK','Not all configured data packets are received from EIB or checksum is not valid','700.EIB',708,'Received Data OK counter',1,'0',2,2),(136,30,'Received Data not OK','Not all configured data packets are received from EIB or checksum is not valid','700.EIB',707,'Received Data OK counter',1,'0',1,2),(137,30,'Bad format udp packet','Data received in upd port does not well formated. The amount of bytes is not corresponding to configured data packet number for EIB','700.EIB',709,'Bad format udp packet counter',1,'0',1,2),(138,30,'Bad format udp packet','Data received in upd port does not well formated. The amount of bytes is not corresponding to configured data packet number for EIB','700.EIB',710,'Bad format udp packet counter',1,'0',2,2),(139,30,'UDP timeout','Encoder UPD loop does not receive any data in 500 ms','700.EIB',711,'UDP Timeout counter',1,'0',2,2),(140,35,'Max Position Limit','The maximum position limit was violated.','1100.BAL',1102,'Position>Max Position',1,'0',2,1),(141,34,'Min Position Limit','The minimum position limit was violated.','1100.BAL',1103,'Position<Min Position',1,'0',2,1),(142,34,'Max Position Limit','The maximum position limit was violated.','1100.BAL',1102,'Position>Max Position',1,'0',2,1),(143,36,'Max Position Limit','The maximum position limit was violated.','1100.BAL',1102,'Position>Max Position',1,'0',2,1),(144,37,'Max Position Limit','The maximum position limit was violated.','1100.BAL',1102,'Position>Max Position',1,'0',2,1),(145,35,'Min Position Limit','The minimum position limit was violated.','1100.BAL',1103,'Position<Min Position',1,'0',2,1),(146,36,'Min Position Limit','The minimum position limit was violated.','1100.BAL',1103,'Position<Min Position',1,'0',2,1),(147,37,'Min Position Limit','The minimum position limit was violated.','1100.BAL',1103,'Position<Min Position',1,'0',2,1),(148,2,'Cabinet Valve Faulty','The cabinet valve is faulty.','1300.CabTemp',1305,'Cabinet Valve Faulty',1,'0',2,1),(149,2,'BackupTemperatureFailed','The backup temperature sensor used when RMC not working failed. The control temperature in the cabinet is not working properly.','1300.CabTemp',1312,'BackupSignalOK',1,'0',2,1),(150,45,'Mirror Cover Safety','A safety issue has occured in the mirror cover module.','1500.MCL',1501,'Safety Switch',1,'0',2,1),(151,15,'Critical Position Limit','This event triggers if the parameter \"Max Position\" is exceeded.','900.MC',902,'Position>Max Position',1,'0',2,1),(152,16,'Critical Position Limit','This event triggers if the parameter \"Max Position\" is exceeded.','900.MC',902,'Position>Max Position',1,'0',2,1),(153,17,'Critical Position Limit','This event triggers if the parameter \"Max Position\" is exceeded.','900.MC',902,'Position>Max Position',1,'0',2,1),(154,18,'Critical Position Limit','This event triggers if the parameter \"Max Position\" is exceeded.','900.MC',902,'Position>Max Position',1,'0',2,1),(155,19,'Critical Position Limit','This event triggers if the parameter \"Max Position\" is exceeded.','1500.MCL',1502,'Position>Max Position',1,'0',2,1),(156,20,'Critical Position Limit','This event triggers if the parameter \"Max Position\" is exceeded.','1500.MCL',1502,'Position>Max Position',1,'0',2,1),(157,21,'Critical Position Limit','This event triggers if the parameter \"Max Position\" is exceeded.','1500.MCL',1502,'Position>Max Position',1,'0',2,1),(158,22,'Critical Position Limit','This event triggers if the parameter \"Max Position\" is exceeded.','1500.MCL',1502,'Position>Max Position',1,'0',2,1),(159,25,'Max Position Limit','The maximum position limit was violated.','1200.DP',1102,'(Position1>Critical Max Platform Position 1)||(Position2>Critical Max Platform Position 2)',1,'0',2,1),(160,25,'Min Position Limit','The minimum position limit was violated.','1200.DP',1103,'(Position1>Critical Min Platform Position 1)||(Position2>Critical Min Platform Position 2)',1,'0',2,1),(161,26,'Max Position Limit','The maximum position limit was violated.','1200.DP',1102,'(Position1>Critical Max Platform Position 1)||(Position2>Critical Max Platform Position 2)',1,'0',2,1),(162,26,'Min Position Limit','The minimum position limit was violated.','1200.DP',1103,'(Position1>Critical Min Platform Position 1)||(Position2>Critical Min Platform Position 2)',1,'0',2,1),(163,47,'SoftMotion Axis Fault','The softmotion axis go to fault','100. Azimuth',101,'fault occurred',1,'0',2,1),(164,49,'SoftMotion Axis Fault','The softmotion axis go to fault','400. Elevation',401,'fault occurred',1,'0',2,1),(165,47,'STO','The STO for the axis is active','100. Azimuth',102,'Safety Switch',1,'0',2,1),(166,44,'MaxCurrent','The maximum allowed current was exceed.','600.MPS',600,'Current > MaxCurrent',0,'0',2,1),(167,44,'MinVoltage','The minimum allowed volage was lost.','600.MPS',601,'Voltage < MinVoltage',0,'0',2,1),(168,15,'ColisionEvent','This event triggers if any MC are going to colision.','900.MC',908,'Colision',0,'0',2,1),(169,16,'ColisionEvent','This event triggers if any MC are going to colision.','900.MC',908,'Colision',0,'0',2,1),(170,17,'ColisionEvent','This event triggers if any MC are going to colision.','900.MC',908,'Colision',0,'0',2,1),(171,18,'ColisionEvent','This event triggers if any MC are going to colision.','900.MC',908,'Colision',0,'0',2,1),(172,49,'STO','The STO for the axis is active','400. Elevation',402,'Safety Switch',1,'0',2,1),(173,47,'Following Error','Excesive Deviation from axis setpoint','100. Azimuth',103,'position error exceeded',1,'0',2,1),(174,49,'Following Error','Excesive Deviation from axis setpoint','400. Azimuth',103,'position error exceeded',1,'0',2,1),(175,49,'Overspeed','Overspeed Error ocurred','400. Azimuth',104,'velocity threshold && Limits Overspeed Enable',1,'0',2,1),(176,47,'Overspeed','Overspeed Error ocurred','100. Azimuth',104,'velocity threshold && Limits Overspeed Enable',1,'0',2,1);
/*!40000 ALTER TABLE `EVENT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `EVENTS`
--

DROP TABLE IF EXISTS `EVENTS`;
/*!50001 DROP VIEW IF EXISTS `EVENTS`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `EVENTS` (
  `ID` tinyint NOT NULL,
  `NAME` tinyint NOT NULL,
  `TYPE` tinyint NOT NULL,
  `EVENTSYSTEM` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `EVENTSYSTEM`
--

DROP TABLE IF EXISTS `EVENTSYSTEM`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EVENTSYSTEM` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(50) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `NAME` (`NAME`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EVENTSYSTEM`
--

LOCK TABLES `EVENTSYSTEM` WRITE;
/*!40000 ALTER TABLE `EVENTSYSTEM` DISABLE KEYS */;
INSERT INTO `EVENTSYSTEM` VALUES (24,'ACWEvents'),(47,'AzimuthAxisEvents'),(33,'BalancingEvents0'),(34,'BalancingEvents1'),(35,'BalancingEvents2'),(36,'BalancingEvents3'),(37,'BalancingEvents4'),(2,'CabTemp'),(12,'CCWEvents'),(49,'ElevationAxisEvents'),(30,'EncoderSystemEvents'),(27,'LockingPinEvents0'),(28,'LockingPinEvents1'),(29,'LockingPinEvents2'),(46,'MainAxisEvents'),(14,'MCEvents0'),(15,'MCEvents1'),(16,'MCEvents2'),(17,'MCEvents3'),(18,'MCEvents4'),(45,'MCLEvents0'),(19,'MCLEvents1'),(20,'MCLEvents2'),(21,'MCLEvents3'),(22,'MCLEvents4'),(44,'MPSEvents'),(40,'OSSEvents'),(32,'PlatformEvents0'),(25,'PlatformEvents1'),(26,'PlatformEvents2'),(38,'TopEndChiller'),(39,'TopEndChillerEvents');
/*!40000 ALTER TABLE `EVENTSYSTEM` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `EVENTSYSTEMS`
--

DROP TABLE IF EXISTS `EVENTSYSTEMS`;
/*!50001 DROP VIEW IF EXISTS `EVENTSYSTEMS`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `EVENTSYSTEMS` (
  `NAME` tinyint NOT NULL,
  `STATECHART` tinyint NOT NULL,
  `STATECHART_ID` tinyint NOT NULL,
  `ID` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `EVENTSYSTEM_TO_INSTANCE`
--

DROP TABLE IF EXISTS `EVENTSYSTEM_TO_INSTANCE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EVENTSYSTEM_TO_INSTANCE` (
  `INSTANCE_ID` int(11) NOT NULL,
  `EVENTSYSTEM_ID` int(11) NOT NULL,
  KEY `FK_EVENTSYSTEM_TO_INSTANCE_EVENTSYSTEM_ID` (`EVENTSYSTEM_ID`),
  KEY `FK_EVENTSYSTEM_TO_INSTANCE_INSTANCE_ID` (`INSTANCE_ID`),
  CONSTRAINT `FK_EVENTSYSTEM_TO_INSTANCE_EVENTSYSTEM_ID` FOREIGN KEY (`EVENTSYSTEM_ID`) REFERENCES `EVENTSYSTEM` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_EVENTSYSTEM_TO_INSTANCE_INSTANCE_ID` FOREIGN KEY (`INSTANCE_ID`) REFERENCES `lsst_settings`.`INSTANCE` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EVENTSYSTEM_TO_INSTANCE`
--

LOCK TABLES `EVENTSYSTEM_TO_INSTANCE` WRITE;
/*!40000 ALTER TABLE `EVENTSYSTEM_TO_INSTANCE` DISABLE KEYS */;
INSERT INTO `EVENTSYSTEM_TO_INSTANCE` VALUES (3,2),(13,12),(23,24),(25,25),(26,26),(41,27),(42,27),(43,27),(42,28),(43,29),(27,30),(24,32),(25,32),(26,32),(36,33),(37,33),(38,33),(39,33),(40,33),(37,34),(38,35),(39,36),(40,37),(46,39),(50,40),(48,44),(15,15),(16,16),(17,17),(18,18),(19,19),(20,20),(21,21),(22,22),(14,14),(15,14),(16,14),(17,14),(18,14),(19,45),(20,45),(21,45),(22,45),(56,45),(45,46),(52,46),(53,46),(52,47),(53,49);
/*!40000 ALTER TABLE `EVENTSYSTEM_TO_INSTANCE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `EVENT_TYPE`
--

DROP TABLE IF EXISTS `EVENT_TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `EVENT_TYPE` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(100) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `EVENT_TYPE`
--

LOCK TABLES `EVENT_TYPE` WRITE;
/*!40000 ALTER TABLE `EVENT_TYPE` DISABLE KEYS */;
INSERT INTO `EVENT_TYPE` VALUES (1,'BOOLEAN'),(2,'DOUBLE');
/*!40000 ALTER TABLE `EVENT_TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TYPE`
--

DROP TABLE IF EXISTS `TYPE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TYPE` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TYPE`
--

LOCK TABLES `TYPE` WRITE;
/*!40000 ALTER TABLE `TYPE` DISABLE KEYS */;
INSERT INTO `TYPE` VALUES (1,'Warning'),(2,'Alarm');
/*!40000 ALTER TABLE `TYPE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `BOOLEAN_EVENTS`
--

/*!50001 DROP TABLE IF EXISTS `BOOLEAN_EVENTS`*/;
/*!50001 DROP VIEW IF EXISTS `BOOLEAN_EVENTS`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`mstoesslein.tekniker.es` SQL SECURITY DEFINER */
/*!50001 VIEW `BOOLEAN_EVENTS` AS select `i`.`NAME` AS `NAME`,`i`.`DESCRIPTION` AS `DESCRIPTION`,`i`.`AREA` AS `AREA`,`i`.`NUMBER` AS `NUMBER`,`i`.`TYPE_ID` AS `TYPE_ID`,`i`.`EVENTSYSTEM_ID` AS `EVENTSYSTEM_ID`,`s`.`NAME` AS `EVENTSYSTEM`,`t`.`NAME` AS `TYPE`,`w`.`NAME` AS `EVENT_TYPE`,`v`.`REF_VALUE` AS `REF_VALUE`,`i`.`EVALUATION_STRING` AS `EVALUATION_STRING`,`i`.`ENABLED` AS `ENABLED`,`i`.`TIME_TO_TRIGGER` AS `TIME_TO_TRIGGER`,`i`.`ID` AS `ID`,`v`.`EVENT_TYPE_ID` AS `EVENT_TYPE_ID` from (((((`EVENT` `i` join `EVENTSYSTEM` `s` on((`i`.`EVENTSYSTEM_ID` = `s`.`ID`))) join `TYPE` `t` on((`i`.`TYPE_ID` = `t`.`ID`))) join `EVENT_TYPE` `u` on((`i`.`EVENT_TYPE_ID` = `u`.`ID`))) join `BOOLEAN_EVENT` `v` on((`i`.`ID` = `v`.`EVENT_ID`))) join `BOOLEAN_TYPE` `w` on((`v`.`EVENT_TYPE_ID` = `w`.`ID`))) where (`u`.`NAME` = 'BOOLEAN') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `DOUBLE_EVENTS`
--

/*!50001 DROP TABLE IF EXISTS `DOUBLE_EVENTS`*/;
/*!50001 DROP VIEW IF EXISTS `DOUBLE_EVENTS`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`mstoesslein.tekniker.es` SQL SECURITY DEFINER */
/*!50001 VIEW `DOUBLE_EVENTS` AS select `i`.`NAME` AS `NAME`,`i`.`DESCRIPTION` AS `DESCRIPTION`,`i`.`AREA` AS `AREA`,`i`.`NUMBER` AS `NUMBER`,`i`.`TYPE_ID` AS `TYPE_ID`,`i`.`EVENTSYSTEM_ID` AS `EVENTSYSTEM_ID`,`s`.`NAME` AS `EVENTSYSTEM`,`t`.`NAME` AS `TYPE`,`w`.`NAME` AS `EVENT_TYPE`,`v`.`REF_VALUE` AS `REF_VALUE`,`i`.`EVALUATION_STRING` AS `EVALUATION_STRING`,`i`.`ENABLED` AS `ENABLED`,`v`.`DEADBAND` AS `DEADBAND`,`v`.`HYSTERESIS` AS `HYSTERESIS`,`i`.`TIME_TO_TRIGGER` AS `TIME_TO_TRIGGER`,`i`.`ID` AS `ID`,`v`.`EVENT_TYPE_ID` AS `EVENT_TYPE_ID` from (((((`EVENT` `i` join `EVENTSYSTEM` `s` on((`i`.`EVENTSYSTEM_ID` = `s`.`ID`))) join `TYPE` `t` on((`i`.`TYPE_ID` = `t`.`ID`))) join `EVENT_TYPE` `u` on((`i`.`EVENT_TYPE_ID` = `u`.`ID`))) join `DOUBLE_EVENT` `v` on((`i`.`ID` = `v`.`EVENT_ID`))) join `DOUBLE_TYPE` `w` on((`v`.`EVENT_TYPE_ID` = `w`.`ID`))) where (`u`.`NAME` = 'DOUBLE') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `EVENTS`
--

/*!50001 DROP TABLE IF EXISTS `EVENTS`*/;
/*!50001 DROP VIEW IF EXISTS `EVENTS`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`mstoesslein.tekniker.es` SQL SECURITY DEFINER */
/*!50001 VIEW `EVENTS` AS select `e`.`ID` AS `ID`,`e`.`NAME` AS `NAME`,`t`.`NAME` AS `TYPE`,`s`.`NAME` AS `EVENTSYSTEM` from ((`EVENT` `e` join `TYPE` `t` on((`e`.`TYPE_ID` = `t`.`ID`))) join `EVENTSYSTEM` `s` on((`e`.`EVENTSYSTEM_ID` = `s`.`ID`))) order by `s`.`NAME`,`t`.`NAME`,`e`.`NAME` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `EVENTSYSTEMS`
--

/*!50001 DROP TABLE IF EXISTS `EVENTSYSTEMS`*/;
/*!50001 DROP VIEW IF EXISTS `EVENTSYSTEMS`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`mstoesslein.tekniker.es` SQL SECURITY DEFINER */
/*!50001 VIEW `EVENTSYSTEMS` AS select distinct `lsst_events`.`EVENTSYSTEM`.`NAME` AS `NAME`,`lsst_settings`.`STATECHART`.`NAME` AS `STATECHART`,`lsst_settings`.`STATECHART`.`ID` AS `STATECHART_ID`,`lsst_events`.`EVENTSYSTEM`.`ID` AS `ID` from (((`lsst_events`.`EVENTSYSTEM` join `lsst_events`.`EVENTSYSTEM_TO_INSTANCE` on((`lsst_events`.`EVENTSYSTEM`.`ID` = `lsst_events`.`EVENTSYSTEM_TO_INSTANCE`.`EVENTSYSTEM_ID`))) join `lsst_settings`.`INSTANCE` on((`lsst_events`.`EVENTSYSTEM_TO_INSTANCE`.`INSTANCE_ID` = `lsst_settings`.`INSTANCE`.`ID`))) join `lsst_settings`.`STATECHART` on((`lsst_settings`.`INSTANCE`.`STATECHART_ID` = `lsst_settings`.`STATECHART`.`ID`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-21  9:54:50
