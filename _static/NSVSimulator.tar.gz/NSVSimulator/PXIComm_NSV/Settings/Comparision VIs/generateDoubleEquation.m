function [Equation, Result] = generateDoubleEquation(Operators, ...
    BracketsOpen,BracketsClose,EquationLength,EquationNegative, ...
    EquationBracketsNumber,NumberRange,ChanceOfExponential, ...
    ExponentialRange,MaxDoubleResult)
%GENERATEDOUBLEEQUATION Summary of this function goes here
%   Detailed explanation goes here

% Code - Do not edit!
Result = sprintf('%f',MaxDoubleResult + 1);
while str2double(Result) > MaxDoubleResult || ...
        str2double(Result) < -MaxDoubleResult
    EquationTerms = rand(EquationLength,1)* ...
        (NumberRange(2) - NumberRange(1)) + NumberRange(1);
    EquationOperatorsIndex = ...
        ceil(rand(EquationLength - 1,1)*numel(Operators));
    EquationBracketsPositionStart = ...
        round(rand(EquationBracketsNumber,1)* ...
        (EquationLength - 1)) + 1;
    EquationBracketsPositionEnd = zeros(EquationBracketsNumber,1);
    for ii = 1:EquationBracketsNumber
        EquationBracketsPositionEnd(ii) = round(rand(1)* ...
            (EquationLength - ...
            EquationBracketsPositionStart(ii)) + ...
            EquationBracketsPositionStart(ii));
    end
    if EquationNegative
        Equation = '-';
    else
        Equation = '';
    end
    for ii = 1:EquationLength
        for kk = 1:sum(ii == EquationBracketsPositionStart)
            Equation = [Equation,BracketsOpen];
        end
        if rand(1) <= ChanceOfExponential && (ii ~= 1 || ~EquationNegative)
            Equation = [Equation, num2str(EquationTerms(ii)), '^', ...
                num2str(rand(1)*(ExponentialRange(2) - ...
                ExponentialRange(1)) + ExponentialRange(1))];
        else
            Equation = [Equation, num2str(EquationTerms(ii))];
        end
        for kk = 1:sum(ii == EquationBracketsPositionEnd)
            Equation = [Equation,BracketsClose];
        end
        if ii ~= EquationLength
            Equation = [Equation, Operators{EquationOperatorsIndex(ii)}];
        end
    end
    Result = num2str(eval(Equation));
end

end

