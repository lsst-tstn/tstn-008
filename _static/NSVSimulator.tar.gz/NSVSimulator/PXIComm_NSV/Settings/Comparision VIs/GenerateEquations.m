% Config - Please edit!
NumberRange = [-1e3, 1e3];
NumberOfEquations = 1000;
EquationLengthRange = [5, 14];
MaxNoOfBrackets = 5;
ExponentialRange = [-5, 5];
ChanceOfExponential = 0.3;
MaxResult = 1e5;

% Code - Do not edit!
Equations = generateDoubleEquations(NumberRange, ...
    NumberOfEquations,EquationLengthRange,MaxNoOfBrackets, ...
    ExponentialRange,ChanceOfExponential,MaxResult);

FID = fopen('DoubleTestVector.lvvect','w');
fprintf(FID,['LabVIEW Unit Test Framework\nVersion 2016\nLibrary\n', ...
    'Namespace\t\n\nInclude\n\nTest Vector\n', ...
    'Input\tResult\nString\tDouble Float\n\n\nsequence\tsequence\n', ...
    'Value Start\tValue Start\n']);
for ii = 1:NumberOfEquations
    fprintf(FID,'%s\t%s\n',Equations{ii,1},Equations{ii,2});
end
fprintf(FID,'Value End\tValue End\n');
fclose(FID);