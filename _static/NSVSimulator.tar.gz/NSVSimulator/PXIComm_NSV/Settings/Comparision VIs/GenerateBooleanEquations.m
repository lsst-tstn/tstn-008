% Config - Please edit!
NumberRange = [-1e3, 1e3];
NumberOfEquations = 1000;
EquationLengthRange = [5, 14];
MaxNoOfBrackets = 5;
ExponentialRange = [-5, 5];
DoubleTermLengthRange = [1, 5];
DoubleTermBracketsRange = [1, 3];
ChanceOfExponential = 0.3;
ChanceOfNumber = 0.3;
MaxDoubleResult = 1e5;
PerformanceTest = 1;

% Code - Do not edit!
DoubleOperators = {'+','-','*','/'};
BooleanBooleanOperators = {'&&','||','==','~='};
BooleanDoubleOperators = {'==','<','>','>=','<=','~='};
BracketsOpen = '(';
BracketsClose = ')';
EquationLength = round(rand(1,NumberOfEquations)* ...
    (EquationLengthRange(2) - EquationLengthRange(1)) + ...
    EquationLengthRange(1));
DoubleOperatorsNumber = floor(EquationLength*ChanceOfNumber);
EquationLength = EquationLength - DoubleOperatorsNumber;
EquationNegative = round(rand(1,NumberOfEquations));
Equations = cell(NumberOfEquations,2);
EquationBracketsNumber = round(rand(NumberOfEquations,1)*MaxNoOfBrackets);
for jj = 1:NumberOfEquations
    EquationTerms = round(rand(EquationLength(jj),1));
    DoubleTermsSelected = randperm(EquationLength(jj), ...
        DoubleOperatorsNumber(jj));
    EquationTerms(DoubleTermsSelected) = 2;
    EquationTermsNegative = round(rand(EquationLength(jj),1)*2);
    EquationOperatorsIndex = ...
        ceil(rand(EquationLength(jj) - 1,1)* ...
        numel(BooleanBooleanOperators));    
    EquationBracketsPositionStart = ...
        round(rand(EquationBracketsNumber(jj),1)* ...
        (EquationLength(jj) - 2) + 1);
    EquationBracketsPositionEnd = zeros(EquationBracketsNumber(jj),1);
    for ii = 1:EquationBracketsNumber(jj)
        EquationBracketsPositionEnd(ii) = round(rand(1)* ...
            (EquationLength(jj) - ...
            (EquationBracketsPositionStart(ii) + 1)) + ...
            (EquationBracketsPositionStart(ii) + 1));
    end
    if EquationNegative(jj) && EquationTerms(1) ~= 2
        Equation = '~';
    else
        Equation = '';
    end
    for ii = 1:EquationLength(jj)
        for kk = 1:sum(ii == EquationBracketsPositionStart)
            Equation = [Equation, BracketsOpen];
        end
        if EquationTermsNegative(ii) > 1 && ii > 1 && ...
                EquationTerms(ii) ~= 2
            Equation = [Equation, '~'];
        end
        if EquationTerms(ii) == 2
            % put in a double term with 2 double sides
            DoubleLength = round(rand(1)*(DoubleTermLengthRange(2) - ...
                DoubleTermLengthRange(1)) + DoubleTermLengthRange(1));
            DoubleBrackets = round(rand(1)*(DoubleTermBracketsRange(2) - ...
                DoubleTermBracketsRange(1)) + DoubleTermBracketsRange(1));
            DoubleTerm1 = generateDoubleEquation(DoubleOperators, ...
                BracketsOpen,BracketsClose,DoubleLength,round(rand(1)), ...
                DoubleBrackets,NumberRange, ChanceOfExponential, ...
                ExponentialRange,MaxDoubleResult);
            DoubleLength = round(rand(1)*(DoubleTermLengthRange(2) - ...
                DoubleTermLengthRange(1)) + DoubleTermLengthRange(1));
            DoubleBrackets = round(rand(1)*(DoubleTermBracketsRange(2) - ...
                DoubleTermBracketsRange(1)) + DoubleTermBracketsRange(1));
            DoubleTerm2 = generateDoubleEquation(DoubleOperators, ...
                BracketsOpen,BracketsClose,DoubleLength,round(rand(1)), ...
                DoubleBrackets,NumberRange, ChanceOfExponential, ...
                ExponentialRange,MaxDoubleResult);
            DoubleOperator = round(rand(1)* ...
                (numel(BooleanDoubleOperators) - 1) + 1);
            Equation = [Equation, BracketsOpen, DoubleTerm1, ...
                BooleanDoubleOperators{DoubleOperator}, DoubleTerm2, ...
                BracketsClose];
        elseif EquationTerms(ii) == 1
            Equation = [Equation, 'true'];
        else
            Equation = [Equation, 'false'];
        end
        for kk = 1:sum(ii == EquationBracketsPositionEnd)
            Equation = [Equation, BracketsClose];
        end
        if ii ~= EquationLength(jj)
            Equation = [Equation, ...
                BooleanBooleanOperators{EquationOperatorsIndex(ii)}];
        end
    end
    Equations{jj,1} = Equation;
    if eval(Equations{jj,1})
        Equations{jj,2} = 'TRUE';
    else
        Equations{jj,2} = 'FALSE';
    end
end

if PerformanceTest
    xlswrite('PerformanceTestsInterpreter.xls',Equations); 
else
    FID = fopen('BooleanTestVector.lvvect','w');
    fprintf(FID,['LabVIEW Unit Test Framework\nVersion 2016\nLibrary\n', ...
        'Namespace\t\n\nInclude\n\nTest Vector\n', ...
        'Input\tResult\nString\tString\n\n\nsequence\tsequence\n', ...
        'Value Start\tValue Start\n']);
    for ii = 1:NumberOfEquations
        fprintf(FID,'%s\t%s\n',Equations{ii,1},Equations{ii,2});
    end
    fprintf(FID,'Value End\tValue End\n');
    fclose(FID);
end