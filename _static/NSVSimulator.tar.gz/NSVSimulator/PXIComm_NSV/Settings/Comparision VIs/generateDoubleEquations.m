function Equations = generateDoubleEquations(NumberRange, ...
    NumberOfEquations,EquationLengthRange,MaxNoOfBrackets, ...
    ExponentialRange,ChanceOfExponential,MaxResult)
%GENERATEDOUBLEEQUATION Summary of this function goes here
%   Detailed explanation goes here

% Code - Do not edit!
Operators = {'+','-','*','/'};
BracketsOpen = '(';
BracketsClose = ')';
EquationLength = round(rand(1,NumberOfEquations)* ...
    (EquationLengthRange(2) - EquationLengthRange(1)) + ...
    EquationLengthRange(1));
EquationNegative = round(rand(1,NumberOfEquations));
Equations = cell(NumberOfEquations,2);
EquationBracketsNumber = round(rand(NumberOfEquations,1)*MaxNoOfBrackets);
jj = 1;
while jj <= NumberOfEquations
    EquationTerms = rand(EquationLength(jj),1)* ...
        (NumberRange(2) - NumberRange(1)) + NumberRange(1);
    EquationOperatorsIndex = ...
        ceil(rand(EquationLength(jj) - 1,1)*numel(Operators));
    EquationBracketsPositionStart = ...
        round(rand(EquationBracketsNumber(jj),1)* ...
        (EquationLength(jj) - 2) + 1);
    EquationBracketsPositionEnd = zeros(EquationBracketsNumber(jj),1);
    for ii = 1:EquationBracketsNumber(jj)
        EquationBracketsPositionEnd(ii) = round(rand(1)* ...
            (EquationLength(jj) - ...
            (EquationBracketsPositionStart(ii) + 1)) + ...
            (EquationBracketsPositionStart(ii) + 1));
    end
    if EquationNegative(jj)
        Equation = '-';
    else
        Equation = '';
    end
    for ii = 1:EquationLength(jj) - 1
        for kk = 1:sum(ii == EquationBracketsPositionStart)
            Equation = [Equation,BracketsOpen];
        end
        if rand(1) <= ChanceOfExponential && (ii ~= 1 || ...
                ~EquationNegative(jj))
            Equation = [Equation, num2str(EquationTerms(ii)), '^', ...
                num2str(rand(1)*(ExponentialRange(2) - ...
                ExponentialRange(1)) + ExponentialRange(1))];
        else
            Equation = [Equation, num2str(EquationTerms(ii))];
        end
        for kk = 1:sum(ii == EquationBracketsPositionEnd)
            Equation = [Equation,BracketsClose];
        end
        Equation = [Equation, Operators{EquationOperatorsIndex(ii)}];
    end
    Equations{jj,1} = [Equation, num2str(EquationTerms(end))];
    for kk = 1:sum(EquationLength(jj) == EquationBracketsPositionEnd)
        Equations{jj,1} = [Equations{jj,1},BracketsClose];
    end
    Equations{jj,2} = num2str(eval(Equations{jj,1}),'%f');
    if MaxResult >= str2double(Equations{jj,2}) && ...
            -MaxResult <= str2double(Equations{jj,2})
        jj = jj + 1;
    end
end

end

