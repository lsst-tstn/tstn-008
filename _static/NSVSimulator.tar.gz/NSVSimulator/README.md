# Use
This repository is used to deploy the network shared variables (NSV) at a different target to the specific TMA PXI where the actual control is executed.

This is done to enter the EUI simulation mode.
## Steps
- Open the project
- Deploy the following libraries:
	- OSS_ModbusServer
	- PXIComm_NSV
	- SafetyModbusComm
	- TEC_ModbusComm
- Execute the SimulateTelemetry.vi to write the deployed variables.
	- If wanted there is a file (SimulateTelemetry.txt) to specify which the variables that will not be simulated.
# Libraries
The libraries at this repository are the ones used at the TMA PXI: 
 - PXIComm_NSV: same submodule as the one used for the HMI and PXI projects.
 - OSS_ModbusServer: same as the one used at the PXI project but modified to remove the modbus server.
 - SafetyModbusComm: same as the one used at the PXI project but modified to remove the modbus server.
 - TEC_ModbusComm: same as the one used at the PXI project but modified to remove the modbus server.
 
 The libraries here are already modified to work well in a windows PC without the modbus server.
## Problem with a library 
 If there is any problem with these libraries there is a VI (SimulateTelemetry.vi) to change the original libraries from the PXI project to remove the modbus server link. To use this VI:
 - Copy the desired library from the PXI project.
 - Open the specified VI.
 - Search for the copied library.
 - Run the VI.
 - Now the library is ready to deploy as it has no longer any linkage to the modbus server.